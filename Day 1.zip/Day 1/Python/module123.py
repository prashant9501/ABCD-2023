def check_prime(num):
    '''
    This function check wether the input number is prime.
    Returns: Bool (True id it is prime, else False)
    '''
    for x in range(2, (num//2) + 1):
#         print(x)
        if num % x == 0:
            return False
            break
    else:
        return True
		

def fun2(x):
    return x**2 + 100
    
def fun3(x):
    return x**3